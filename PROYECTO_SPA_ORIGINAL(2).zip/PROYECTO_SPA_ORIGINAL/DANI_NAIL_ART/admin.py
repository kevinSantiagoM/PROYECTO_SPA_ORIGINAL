from django.contrib import admin
from .models import Servicio, Cita

admin.site.register(Cita)
admin.site.register(Servicio)

# Register your models here.
