from django.apps import AppConfig


class DaniNailArtConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'DANI_NAIL_ART'
