from django import forms
from .models import Servicio, Promociones, Galeria,Crear_cita_promocion
from .models import Cita

#---------------CREAR CITAS------------------------------------
class CitaForm(forms.ModelForm):
    class Meta:
        model = Cita
        fields = ['nombre', 'descripcion', 'precio', 'fecha', 'hora']

        widgets = {
            'fecha': forms.DateInput(attrs={'type': 'date'}),
            'hora': forms.TimeInput(attrs={'type': 'time'}),
        }


     
#-----------------AGREGAR SERVICIOS-----------------------------
class Agendar_Servicio(forms.ModelForm):
    class Meta:
        model = Servicio
        fields = ['nombre', 'descripcion', 'disponibilidad', 'precio', 'imagen']

#-----------------AGREGAR PROMOCIONES
class Agendar_PromocionesForm(forms.ModelForm):
    class Meta:
        model = Promociones
        fields = ['nombre', 'descripcion', 'disponibilidad', 'precio', 'imagen']

#---------------AGREGAR IMAGENES------------------------
class Agendar_Galeria(forms.ModelForm):

    class Meta: 
        model = Galeria
        fields = ['imagen']


#---------------CREAR CITAS DE PROMOCION------------------------------------
class Cita_promoForm(forms.ModelForm):
    nombre_promocion = forms.CharField(widget=forms.HiddenInput(), required=False)

    class Meta:
        model = Crear_cita_promocion
        fields = ['nombre_promocion', 'nombre', 'descripcion', 'precio', 'fecha', 'hora']

        widgets = {
            'fecha': forms.DateInput(attrs={'type': 'date'}),
            'hora': forms.TimeInput(attrs={'type': 'time'}),
        }

     