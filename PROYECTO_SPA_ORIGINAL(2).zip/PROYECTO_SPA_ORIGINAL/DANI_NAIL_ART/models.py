from django.db import models
from django.core.validators import MinValueValidator


from django.db import models
from django.core.validators import MinValueValidator

class Servicio(models.Model):
    nombre = models.CharField(max_length=100)
    descripcion = models.CharField(max_length=100)
    disponibilidad = models.BooleanField()
    precio = models.DecimalField(max_digits=10, decimal_places=3, validators=[MinValueValidator(0)])
    imagen = models.ImageField(default='default_image.jpg')

    def __str__(self):
        return self.nombre


class Cita(models.Model):
    nombre = models.CharField(max_length=100, null=True, blank=True)
    descripcion = models.CharField(max_length=100)
    precio = models.CharField(max_length=100)  
    fecha = models.DateField()
    hora = models.TimeField()

    def __str__(self):
        return self.nombre


class Promociones(models.Model):
    nombre = models. CharField(max_length=100)
    descripcion = models.CharField(max_length=100)
    disponibilidad = models.BooleanField()
    precio = models.DecimalField(max_digits=10, decimal_places=3, validators=[MinValueValidator(0)])
    imagen = models.ImageField()


class Galeria(models.Model):
     imagen = models.ImageField()




class Crear_cita_promocion(models.Model):
    nombre = models.CharField(max_length=100)
    descripcion = models.CharField(max_length=100)
    precio = models.CharField(max_length=100)  # Cambiado a CharField
    fecha = models.DateField()
    hora = models.TimeField()

    def __str__(self):
        return self.nombre


   