from django.urls import path
from . import views
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path('', views.inicio_sesion, name='InicioSeccion'),

    path('regitrar/', views.regitro, name='Registrar'),

    path('logout/', views.signout, name='Salir'),

    path('crear/', views.crear_cita, name='crear_cita'),

    path('citas_agendadas/', views.lista_citas, name='lista_citas'),
    
    path('editar/<int:cita_id>/', views.editar_cita, name='editar_cita'),

    path('eliminar_cita/<int:cita_id>/', views.eliminar_cita, name='eliminar_cita'),

    path('Menu', views.Menu, name='Menu'),

    path('Agregar_servicio/', views.añadir_Servicios, name='Agregar_Servicio'),

    path('Servicios_agendados/', views.Servicios, name='Servicios_agendados'),
    
    #-------------------Editar servicio-------------------------------------------------
    path('editar_servicio/<int:servicio_id>/', views.editar_servicio, name='editar_servicio'),

    #-------------------Sericios cliente-------------------------------------------------
    path('servicio_cliente/', views.servicio_cliente, name='servicio_cliente'),

    #---------------Eliminar-servicio-------------------------------------------
    path('eliminar_servicio/<int:servicio_id>/', views.eliminar_servicio, name='eliminar_servicio'),

    #-------------------Base admin-------------------------------------------------
    path('base_admin/', views.base_admin, name='base_admin'),

    #-------------------Base-------------------------------------------------
    path('base/', views.base, name='base'),

    #------------Metodo de pago---------------
    path('metodo_pago/', views.metodo_pago, name='metodo_pago'),

    #----------Contacto--------------------------------------
    path('contacto/', views.contacto, name='contacto'),

    #----------Promociones--------------------------------------
    path('promociones/', views.promociones, name='promociones'),

    #------------PROMOCIONES ADMINISTRADOR-----------------
    path('Promociones_agendadas/', views.Promociones_agendadas, name='Promociones_agendadas'),

    #----------Agregar Promociones--------------------------------------
    path('Agendar_Promociones/', views.Agendar_Promociones, name='Agendar_Promociones' ),

    #----------Galeria de imagenes--------------------------------------
    path('galeria/', views.galeria, name='galeria'),

    #------------AGREGAR GALERIA-----------------
    path('Agregar_galeria/', views.Agregar_galeria, name='Agregar_galeria'),

     #-------------------Editar Promocion-------------------------------------------------
    path('editar_promocion/<int:promocion_id>/', views.editar_promocion, name='editar_promocion'),

     #-------------------Eliminar Promocion-------------------------------------------------
    path('eliminar_promocion/<int:promocion_id>/', views.eliminar_promocion, name='eliminar_promocion'),

    #-------------------CREAR CITA PROMOCION------------------------------------------------
    path('crear_cita_promo/', views.crear_cita_promo, name='crear_cita_promo'),

    #-------------------EDITAR CITA PROMOCION------------------------------------------------
    path('editar_cita_promocion/<int:cita_promocion_id>/', views.editar_cita_promocion, name='editar_cita_promocion'),

    #---------------ELIMINAR CITA PROMOCION----------------
    path('eliminar_cita_promocion/<int:cita_promocion_id>/', views.eliminar_cita_promocion, name='eliminar_cita_promocion'),

    #---------------HISTORIAL DE CITAS ADMINISTRADOR----------------
    path('Historial_admin/', views.Historial_admin, name='Historial_admin'),
    
]

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)