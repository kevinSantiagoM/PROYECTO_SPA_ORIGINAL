from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login, logout, authenticate
from django.http import JsonResponse, HttpResponseRedirect
from django.contrib.auth.models import User
from django.db import IntegrityError
from .forms import CitaForm, Agendar_Servicio, Agendar_Galeria, Cita_promoForm
from .models import Cita, Servicio, Galeria
from .models import Promociones, Crear_cita_promocion
from .forms import Agendar_PromocionesForm
from django.urls import reverse
from django.contrib import messages

def incio(request):
    titulo = "hello bich"
    return render(request, 'Login/inicio.html', {
        'titulo':titulo
    })

def Menu(request):
    return render(request, 'Menu.html')

#--------------------REGISTRARSE-----------------------------
def regitro(request):
    if request.method == 'GET':
        return render(request, 'Register/registrar.html', {"form": UserCreationForm})
    else:

        if request.POST["password1"] == request.POST["password2"]:
            try:
                user = User.objects.create_user(
                    request.POST["username"], password=request.POST["password1"])
                user.save()
                login(request, user)
                return redirect('InicioSeccion')
            except IntegrityError:
                return render(request, 'Register/registrar.html', {"form": UserCreationForm, "error": "Username already exists."})

        return render(request, 'Register/registrar.html', {"form": UserCreationForm, "error": "Passwords did not match."})

#----------------------INICIO DE SESIÓN----------------------------
def inicio_sesion(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(request, username=username, password=password)

            if user is not None:
                login(request, user)

                # Verificar si el usuario es un administrador
                if user.is_staff:
                    return redirect('base_admin')  # Redirigir a base_admin.html para el administrador
                else:
                    return redirect('base')  # Redirigir a base.html para usuarios no administradores

    else:
        form = AuthenticationForm()

    return render(request, 'Login/inicio.html', {'form': form})

#----------------------CERRAR SESIÓN-----------------------------
def signout(request):
    logout(request)
    return redirect('inincio')

#-------------------LISTA DE CITAS------------------------------------------
def lista_citas(request):
    citas = Cita.objects.all()
    citas_promocion = Crear_cita_promocion.objects.all()
    return render(request, 'Citas/lista_citas.html', {'citas': citas, 'citas_promocion': citas_promocion})


#------------------------CREAR CITA-------------------------------

def crear_cita(request):
    if request.method == 'POST':
        form = CitaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_citas')
    else:

        nombre_servicio = request.GET.get('nombre_servicio', '')
        descripcion_servicio = request.GET.get('descripcion_servicio', '')
        precio_servicio = request.GET.get('precio_servicio', '')

        
        form = CitaForm(initial={
            'nombre_servicio' : nombre_servicio,
            'nombre' :nombre_servicio,
            'descripcion': descripcion_servicio,
            'precio' : precio_servicio

        })

    return render(request, 'Citas/crear_cita.html', {'form': form})


#---------------------------EDITAR CITA-------------------------------------
def editar_cita(request, cita_id):
    cita = get_object_or_404(Cita, pk=cita_id)
    
    if request.method == 'POST':
        form = CitaForm(request.POST, instance=cita)
        if form.is_valid():
            form.save()
            return redirect('lista_citas')
    else:
        form = CitaForm(instance=cita)
    return render(request, 'Citas/editar_cita.html', {'form': form, 'cita': cita})

#----------------------ELIMINAR CITA----------------------------------
def eliminar_cita(request, cita_id):
    try:
        cita = Cita.objects.get(id=cita_id)
        cita.delete()
        messages.success(request, 'La cita ha sido eliminada exitosamente.')
    except Cita.DoesNotExist:
        messages.error(request, 'La cita no se encontró o no pudo ser eliminada.')

    return redirect(reverse('lista_citas'))

#---------------------------AÑADIR SERVICIO---------------------------------
def añadir_Servicios( request ):
    if request.method == 'POST':
        form = Agendar_Servicio(request.POST, request.FILES)
        if form.is_valid():
            nombre = form.cleaned_data['nombre']
            disponibilidad = form.cleaned_data['disponibilidad']
            precio = form.cleaned_data['precio']
            imagen = form.cleaned_data['imagen']
            Servicio.objects.create(
                nombre=nombre,
                disponibilidad=disponibilidad,
                precio=precio,
                imagen=imagen,
            )
            return redirect('/Servicios_agendados')
    else:
        form = Agendar_Servicio()

    return render(request, 'Servicios/Agregar_Servcios.html', {
        'form': form, 
    })

# --------------Servicios_administrador--------------------------------------------
def Servicios(request):
    servicio = Servicio.objects.all()
    return render(request, 'Servicios/Servicios_agendados.html', {
        'servicio':servicio,
    })

#------------------SERVICIS DEL CLIENTE---------------------
def servicio_cliente(request):
    servicio = Servicio.objects.all()
    return render(request, 'Servicios/Servicios_cliente.html', {
        'servicio':servicio,
    })

#---------------EDITAR SERVICIOS--------------------
def editar_servicio(request, servicio_id):
    servicio = get_object_or_404(Servicio, pk=servicio_id)
    
    if request.method == 'POST':
        form = Agendar_Servicio(request.POST, request.FILES, instance=servicio)
        if form.is_valid():
            form.save()
            return redirect('Servicios_agendados')
    else:
        form = Agendar_Servicio(instance=servicio)
    return render(request, 'Servicios/editar_servicio.html', {'form': form, 'servicio': servicio})

#---------------ELIMINAR SERVICIOS---------------------
def eliminar_servicio(request, servicio_id):
    try:
        servicio = Servicio.objects.get(id=servicio_id)
        servicio.delete()
        messages.success(request, 'La cita ha sido eliminada exitosamente.')
    except Servicio.DoesNotExist:
        messages.error(request, 'La cita no se encontró o no pudo ser eliminada.')

    return redirect(reverse('Servicios_agendados'))

#------------BASE ADMINISTRADOR----------------
def base_admin(request):
    servicio = Servicio.objects.all()
    return render(request, 'Servicios/Servicios_agendados.html', {
        'servicio':servicio,
    })

#------------DABSE USUARIO-----------------
def base(request):
    return render(request, 'Menu.html')

#------------METODO DE PAGO-----------------
def metodo_pago(request):
    return render(request,'Metodopagos/Metodos_pago.html')

#------------CONTACTO-----------------
def contacto(request):
    return render(request, 'Contacto/Contacto.html')

#------------PROMOCIONES USUARIO-----------------
def promociones(request):
    promociones = Promociones.objects.all()
    return render(request, 'Promociones/Promociones.html', {'promociones': promociones})

#------------AGREGAR PROMOCIONES---------------------
def Agendar_Promociones(request):
    if request.method == 'POST':
        form = Agendar_PromocionesForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('Promociones_agendadas')
    else:
        form = Agendar_PromocionesForm()

    return render(request, 'Promociones/Agregar_promo.html', {'form': form})

#------------PROMOCIONES ADMINISTRADOR-----------------
def Promociones_agendadas(request):
    promociones = Promociones.objects.all()
    return render(request, 'Promociones/Promociones_admin.html', {'promociones': promociones})

#--------------ELIMINAR PROMOCIONES------------------
def eliminar_promocion(request, promocion_id):
    try:
        promocion = Promociones.objects.get(id=promocion_id)
        promocion.delete()
        messages.success(request, 'La promoción ha sido eliminada exitosamente.')
    except Promociones.DoesNotExist:
        messages.error(request, 'La promoción no se encontró o no pudo ser eliminada.')

    return redirect(reverse('Promociones_agendadas'))

#------------AGREGAR GALERIA-----------------
# views.py


def Agregar_galeria(request):
    imagenes_galeria = Galeria.objects.all()

    if request.method == 'POST':
        form = Agendar_Galeria(request.POST, request.FILES)
        if form.is_valid():
            form.save()

            # Obtener todas las imágenes de la galería después de guardar la nueva
            imagenes_galeria = Galeria.objects.all()

            # Crear un nuevo formulario vacío para la próxima carga de la página
            new_form = Agendar_Galeria()

            # Puedes redirigir a la página de Galería_admin.html o a donde desees
            return render(request, 'Galeria/Agregar_galeria.html', {'form': new_form, 'imagenes_galeria': imagenes_galeria})
    else:
        # Si es una solicitud GET, simplemente renderiza el formulario y las imágenes
        form = Agendar_Galeria()

    return render(request, 'Galeria/Agregar_galeria.html', {'form': form, 'imagenes_galeria': imagenes_galeria})



#----------GALERIA USUARIO-------------
def galeria(request):
    imagenes_galeria = Galeria.objects.all()
    return render(request, 'Galeria/Galeria.html', {'imagenes_galeria': imagenes_galeria})

#----------EDITAR PROMOCION-------------

def editar_promocion(request, promocion_id):
    promocion = get_object_or_404(Promociones, pk=promocion_id)

    if request.method == 'POST':
        form = Agendar_PromocionesForm(request.POST, request.FILES, instance=promocion)
        if form.is_valid():
            form.save()
            return redirect('Promociones_agendadas')
    else:
        form = Agendar_PromocionesForm(instance=promocion)

    return render(request, 'Promociones/Editar_promocion.html', {'form': form, 'promocion': promocion})

#----------CREAR CITA PROMOCION-------------
def crear_cita_promo(request):
    if request.method == 'POST':
        form = Cita_promoForm(request.POST)
        if form.is_valid():
            # Guardar la cita en la base de datos
            form.save()
            
            # Redireccionar a la página de historial
            return redirect('lista_citas')  # Asegúrate de que esta sea la URL correcta
    else:
        # Obtener parámetros de la promoción desde la URL
        nombre_promocion = request.GET.get('nombre_promocion', '')
        descripcion_promocion = request.GET.get('descripcion_promocion', '')
        precio_promocion = request.GET.get('precio_promocion', '')

        # Inicializar el formulario con estos parámetros
        form = Cita_promoForm(initial={
            'nombre_promocion': nombre_promocion,
            'nombre': nombre_promocion,  # Asegúrate de que el formulario tenga estos campos
            'descripcion': descripcion_promocion,
            'precio': precio_promocion,
        })

    return render(request, 'Citas/crear_cita_promocion.html', {'form': form})


#----------HISTORIAL DE CITAS ADMINITRADOR-------------

def Historial_admin(request):
    citas = Cita.objects.all()
    citas_promocion = Crear_cita_promocion.objects.all()
    return render(request, 'Citas/Historia_admin.html', {'citas': citas, 'citas_promocion': citas_promocion})

#-----------------EDITAR CITA DE POMOCION---------------------

def editar_cita_promocion(request, cita_promocion_id):
    cita_promocion = get_object_or_404(Crear_cita_promocion, pk=cita_promocion_id)
    
    if request.method == 'POST':
        form = Cita_promoForm(request.POST, instance=cita_promocion)
        if form.is_valid():
            form.save()
            return redirect('lista_citas')  # Puedes cambiar la URL a la página deseada
    else:
        form = Cita_promoForm(instance=cita_promocion)
    
    return render(request, 'Citas/Editar_cita_promocion.html', {'form': form, 'cita_promocion': cita_promocion})

#-----------------ELIMINAR CITA DE POMOCION---------------------

def eliminar_cita_promocion(request, cita_promocion_id):
    try:
        cita_promocion = get_object_or_404(Crear_cita_promocion, id=cita_promocion_id)
        cita_promocion.delete()
        messages.success(request, 'La cita de promoción ha sido eliminada exitosamente.')
    except Crear_cita_promocion.DoesNotExist:
        messages.error(request, 'La cita de promoción no se encontró o no pudo ser eliminada.')

    return redirect(reverse('lista_citas'))  

